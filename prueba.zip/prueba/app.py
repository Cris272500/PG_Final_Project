import numpy as np
import trimesh
import glfw
import pyrender
from pyrender import PerspectiveCamera, DirectionalLight, Viewer

# Ruta al archivo GLTF
gltf_file = 'projectPG.gltf'

# Intentar cargar el archivo GLTF
try:
    print(f"Cargando archivo: {gltf_file}")
    loaded = trimesh.load(gltf_file)
    if loaded is None:
        raise ValueError(f"Error al cargar el archivo {gltf_file}: El archivo no pudo ser cargado correctamente.")
except Exception as e:
    print(f"Error al cargar el archivo {gltf_file}: {e}")
    loaded = None

# Verificar si se cargó correctamente como una escena o un objeto Trimesh
if isinstance(loaded, trimesh.Scene):
    # Unir todas las mallas de la escena en una sola
    meshes = loaded.dump()
    # Convertir cada Trimesh a un objeto pyrender.Mesh
    pyrender_meshes = [pyrender.Mesh.from_trimesh(mesh, smooth=False) for mesh in meshes]
elif isinstance(loaded, trimesh.Trimesh):
    # Convertir a un objeto pyrender.Mesh
    pyrender_meshes = [pyrender.Mesh.from_trimesh(loaded, smooth=False)]
else:
    print(f"No se pudo cargar el archivo {gltf_file} correctamente.")
    pyrender_meshes = []

# Crear una escena de pyrender
scene = pyrender.Scene()
for mesh in pyrender_meshes:
    scene.add(mesh)

# Crear una cámara
camera = PerspectiveCamera(yfov=np.pi / 3.0)
camera_pose = np.array([[1.0, 0.0, 0.0, 0.0],
                        [0.0, 1.0, 0.0, 0.0],
                        [0.0, 0.0, 1.0, 3.0],  # Ajustar la posición Z de la cámara
                        [0.0, 0.0, 0.0, 1.0]])
scene.add(camera, pose=camera_pose)

# Añadir luz a la escena
light = DirectionalLight(color=np.ones(3), intensity=2.0)
light_pose = np.array([[1.0, 0.0, 0.0, 0.0],
                       [0.0, 1.0, 0.0, 0.0],
                       [0.0, 0.0, 1.0, 3.0],  # Ajustar la posición Z de la luz
                       [0.0, 0.0, 0.0, 1.0]])
scene.add(light, pose=light_pose)

# Inicializar GLFW y configurar la ventana
if not glfw.init():
    raise RuntimeError('No se pudo inicializar GLFW')

glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 3)
glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 3)
glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

# Crear la ventana
window = glfw.create_window(800, 600, "PyRender GLFW Example", None, None)
if not window:
    glfw.terminate()
    raise RuntimeError('No se pudo crear la ventana GLFW')

glfw.make_context_current(window)

# Crear el visor de PyRender
viewer = Viewer(scene, use_raymond_lighting=True)

# Ciclo principal de renderizado
while not glfw.window_should_close(window):
    glfw.poll_events()

    # Renderizar la escena
    viewer.render_lock.acquire()
    viewer.render_lock.release()

    # Intercambiar buffers y actualizar la ventana
    glfw.swap_buffers(window)

glfw.terminate()

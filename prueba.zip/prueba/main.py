import pyrender
import numpy as np
import glfw
import trimesh  # Agrega esta línea para importar trimesh

# Resto de tu código sigue aquí...

# Clase personalizada para agregar controles WASD
class CustomViewer(pyrender.Viewer):
    def __init__(self, scene, **kwargs):
        super().__init__(scene, **kwargs)
        self.key_down = set()
        self.move_speed = 0.05
        self.rot_speed = 0.02

    def key_callback(self, window, key, scancode, action, mods):
        if action == glfw.PRESS:
            self.key_down.add(key)
        elif action == glfw.RELEASE:
            self.key_down.discard(key)
        super().key_callback(window, key, scancode, action, mods)

    def rotate_camera(self, dx, dy):
        self._camera_pose = np.dot(self._camera_pose, pyrender.camera.rotate_around_x(dx * self.rot_speed))
        self._camera_pose = np.dot(self._camera_pose, pyrender.camera.rotate_around_y(dy * self.rot_speed))

    def step(self, *args, **kwargs):
        if glfw.KEY_W in self.key_down:
            self._camera_pose[2, 3] -= self.move_speed
        if glfw.KEY_S in self.key_down:
            self._camera_pose[2, 3] += self.move_speed
        if glfw.KEY_A in self.key_down:
            self._camera_pose[0, 3] -= self.move_speed
        if glfw.KEY_D in self.key_down:
            self._camera_pose[0, 3] += self.move_speed

        super().step(*args, **kwargs)

# Crear una escena de pyrender
scene = pyrender.Scene()

# Crear el skybox con seis caras
skybox_verts = np.array([
    [-1, -1, -1],
    [ 1, -1, -1],
    [ 1,  1, -1],
    [-1,  1, -1],
    [-1, -1,  1],
    [ 1, -1,  1],
    [ 1,  1,  1],
    [-1,  1,  1]
])

skybox_faces = np.array([
    [0, 1, 2],
    [0, 2, 3],
    [1, 5, 6],
    [1, 6, 2],
    [5, 4, 7],
    [5, 7, 6],
    [4, 0, 3],
    [4, 3, 7],
    [3, 2, 6],
    [3, 6, 7],
    [4, 5, 1],
    [4, 1, 0]
])

skybox_mesh = pyrender.Mesh.from_trimesh(trimesh.Trimesh(vertices=skybox_verts, faces=skybox_faces), smooth=False)

# Cargar las texturas del skybox
skybox_textures = [
    'right.jpg', 'left.jpg',
    'top.jpg', 'bottom.jpg',
    'front.jpg', 'back.jpg'
]

# Crear texturas y asignarlas al skybox
for i, texture_path in enumerate(skybox_textures):
    texture = pyrender.Texture(source=pyrender.ImageLoader.load(texture_path))
    skybox_mesh.textures.append(texture)

# Agregar el skybox a la escena
scene.add(skybox_mesh)

# Crear una cámara
camera = pyrender.PerspectiveCamera(yfov=(np.pi / 3.0))
camera_pose = np.array([[1.0, 0.0, 0.0, 0.0],
                        [0.0, 1.0, 0.0, 0.0],
                        [0.0, 0.0, 1.0, 1.5],
                        [0.0, 0.0, 0.0, 1.0]])
scene.add(camera, pose=camera_pose)

# Añadir luz a la escena
light = pyrender.DirectionalLight(color=np.ones(3), intensity=2.0)
scene.add(light, pose=camera_pose)

# Abrir el visor interactivo con controles personalizados
viewer = CustomViewer(scene, use_raymond_lighting=True, run_in_thread=False)

